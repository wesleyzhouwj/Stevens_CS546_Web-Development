const recipesData = require("./recipes");

module.exports = {
  recipes: recipesData,
};