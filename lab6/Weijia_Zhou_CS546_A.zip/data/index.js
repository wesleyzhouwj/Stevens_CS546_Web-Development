const postData = require("./posts");

module.exports = {
  posts: postData
};
//Ask TA for this part, the relationship between this part and posts